import * as jQuery from 'jquery';
(window as any).jQuery = jQuery;
(window as any).$ = jQuery;
