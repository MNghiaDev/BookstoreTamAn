import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthorService } from '../../services/author.service';
import { Author } from '../../models/author';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { BookService } from '../../services/book.service';
import { IBookList } from '../../models/book';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-author-detail',
  imports: [HeaderComponent, FooterComponent, CommonModule, RouterLink],
  templateUrl: './author-detail.component.html',
  styleUrl: './author-detail.component.css'
})
export class AuthorDetailComponent implements OnInit{
  authorId! : number;
  author : Author = new Author();
  bookList : IBookList[] = [];

  currentPage: number = 0;
  totalPages: number = 0;
  size: number = 18;

  totalBooks : number = 0;

  previewPage(){
    this.currentPage = this.currentPage - 1;
  }
  nextPage(){
    this.currentPage = this.currentPage + 1;
  }

  constructor(private route: ActivatedRoute, private authorService : AuthorService, private bookService : BookService){}
  ngOnInit(): void {
    this.authorId = Number(this.route.snapshot.paramMap.get('id'));
    this.onAuthorDetail();
    this.onSelectBookByAuthor();
  }

  onAuthorDetail(){
    this.authorService.getAuthorById(this.authorId).subscribe((res : any) => {
      this.author = res.data;
    })
  }
  onSelectBookByAuthor(){
    this.bookService.bookByAuthor(this.authorId, this.currentPage, this.size).subscribe((res : any) => {
      this.bookList = res.data.productResponses;
    })
  }
}
