import { AfterViewInit, Component, OnInit } from '@angular/core';
import { BookService } from '../../../../services/book.service';
import { IBookList } from '../../../../models/book';
import $ from 'jquery'; // Default import for jQuery
import 'owl.carousel'; // Import Owl Carousel

@Component({
  selector: 'app-best-selling',
  templateUrl: './best-selling.component.html',
  styleUrl: './best-selling.component.css'
})
export class BestSellingComponent implements AfterViewInit {
  bookList: IBookList[] = [];

  constructor(private bookService: BookService) {

  }


  topSelling() {
    debugger;
    this.bookService.topSelling().subscribe((res: any) => {
      this.bookList = res.data;
    });
  }

  ngAfterViewInit(): void {
    ($('.tg-bestsellingbook-slider') as any).owlCarousel({
      items: 5,
      loop: true,
      margin: 30,
      autoplay: true,
      autoplayTimeout: 3000,
      nav: true,
      dots: false
    });
  }
}
