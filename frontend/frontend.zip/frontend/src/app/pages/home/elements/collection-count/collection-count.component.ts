import { Component } from '@angular/core';

@Component({
  selector: 'app-collection-count',
  imports: [],
  templateUrl: './collection-count.component.html',
  styleUrl: './collection-count.component.css'
})
export class CollectionCountComponent {

}
