import { Component } from '@angular/core';

@Component({
  selector: 'app-new-release',
  imports: [],
  templateUrl: './new-release.component.html',
  styleUrl: './new-release.component.css'
})
export class NewReleaseComponent {

}
