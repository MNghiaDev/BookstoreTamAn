import { Component } from '@angular/core';

@Component({
  selector: 'app-picked-by-author',
  imports: [],
  templateUrl: './picked-by-author.component.html',
  styleUrl: './picked-by-author.component.css'
})
export class PickedByAuthorComponent {

}
