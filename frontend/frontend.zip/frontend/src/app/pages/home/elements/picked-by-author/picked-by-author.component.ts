import { Component, OnInit, AfterViewChecked } from '@angular/core';
import $ from 'jquery';
import { BookService } from '../../../../services/book.service';

@Component({
  selector: 'app-picked-by-author',
  templateUrl: './picked-by-author.component.html',
  styleUrls: ['./picked-by-author.component.css']
})
export class PickedByAuthorComponent implements OnInit, AfterViewChecked {
  listTopBooksByTopAuthors: any[] = [];
  carouselInitialized = false;

  constructor(private bookService: BookService) {}

  ngOnInit(): void {
    this.topBooksByTopAuthors();
  }

  ngAfterViewChecked(): void {
    // Chỉ khởi tạo 1 lần sau khi DOM đã render
    if (this.listTopBooksByTopAuthors.length > 0 && !this.carouselInitialized) {
      $('#tg-pickedbyauthorslider').owlCarousel({
        items: 3,
        margin: 30,
        loop: true,
        nav: true,
        dots: false,
        navText: [
          '<i class="fa fa-angle-left"></i>',
          '<i class="fa fa-angle-right"></i>'
        ],
        responsive: {
          0: { items: 1 },
          600: { items: 2 },
          1000: { items: 3 }
        }
      });
      this.carouselInitialized = true; // đánh dấu đã init rồi
    }
  }

  topBooksByTopAuthors() {
    this.bookService.topBooksByTopAuthors().subscribe((res: any) => {
      this.listTopBooksByTopAuthors = res.data;
    });
  }
}
