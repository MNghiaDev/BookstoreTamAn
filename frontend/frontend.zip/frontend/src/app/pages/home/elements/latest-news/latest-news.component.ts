import { Component } from '@angular/core';

@Component({
  selector: 'app-latest-news',
  imports: [],
  templateUrl: './latest-news.component.html',
  styleUrl: './latest-news.component.css'
})
export class LatestNewsComponent {

}
