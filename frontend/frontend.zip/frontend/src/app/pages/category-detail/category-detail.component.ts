import { Component } from '@angular/core';

@Component({
  selector: 'app-category-detail',
  imports: [],
  templateUrl: './category-detail.component.html',
  styleUrl: './category-detail.component.css'
})
export class CategoryDetailComponent {

}
