import { NgIf } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-payment-callback',
  imports: [NgIf],
  templateUrl: './payment-callback.component.html',
  styleUrl: './payment-callback.component.css'
})
export class PaymentCallbackComponent implements OnInit{
  status: string = '';
  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.status = params['status'];
      const orderId = params['orderId'];

      if (this.status === '00') {
        this.http.put(`http://localhost:8080/payment/confirm-success/${orderId}`, {})
          .subscribe(() => {
            localStorage.removeItem('checkoutItems');
            this.router.navigate(['/thank-you']);
          });
      }
    });
  }
}
