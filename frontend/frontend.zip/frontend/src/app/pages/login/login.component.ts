import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { error } from 'jquery';
import { jwtDecode } from 'jwt-decode';
import { UserService } from '../../services/user.service';
import { TokenService } from '../../services/token.service';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  
  isSignUpMode: boolean = false;

  toggleSignUp() {
    this.isSignUpMode = true;
  }

  toggleSignIn() {
    this.isSignUpMode = false;
  }

  loginObj : any = {
    username : '',
    password : ''
  }

  apiLoginObj : any = {
    username : '',
    password : ''
  }

  constructor(private userService : UserService, private tokenService : TokenService){}

  router = inject(Router);
  onLogin(){
    debugger;
    this.userService.login(this.loginObj).subscribe((res : any) => {
      const tokenDecoded : any = jwtDecode(res.data.token);
      const scope = tokenDecoded.scope;
      this.tokenService.setToken(res.data.token);
      debugger;
      if(scope == "ROLE_admin"){
        this.router.navigateByUrl("dashboard");
        debugger;
      }else{
        this.router.navigateByUrl("home");
      }
    }, error => {
      alert("Wrong credentials");
    })
  }
}
