
export class Author{
    id : 0;
    name: string;
    bio : string;
    imageUrl : string;

    constructor(){
        this.id = 0;
        this.name = "";
        this.bio = "";
        this.imageUrl = "";
    }
}

export interface IAuthorList{
    id : 0;
    name: string;
    bio : string;
    imageUrl : string;
}