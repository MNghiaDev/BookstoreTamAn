export class CategoryNames{
    name : string

    constructor(){
        this.name = "";
    }
}

export interface ICategoryNames{
    name : String
}
