import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthorService {

  apiUrl : string = "http://localhost:8080/api/bookstore/author";

  constructor(private http : HttpClient) { }

  topAuthor(){
    return this.http.get(this.apiUrl + "/top-authors");
  }

  getAll(page: number, size : number){
    return this.http.get(`${this.apiUrl}/list?page=${page}&size=${size}`);
  }
  getAuthorById(id : number){
    return this.http.get(`${this.apiUrl}/${id}`);
  }
}
