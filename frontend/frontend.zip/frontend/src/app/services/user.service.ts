import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  apiUrl : string = "http://localhost:8080/api/bookstore/auth";

  constructor(private http : HttpClient) { }

  login(loginObj : any){
    return this.http.post(this.apiUrl + '/token', loginObj);
  }
}
