import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  apiUrl : string = "http://localhost:8080/api/bookstore/cart";
  private storageKey = 'cartItems';

  constructor(private http : HttpClient) { }
  // ====== LocalStorage Methods ======

  getLocalCart(): any[] {
    const cart = localStorage.getItem(this.storageKey);
    return cart ? JSON.parse(cart) : [];
  }

  saveLocalCart(cart: any[]): void {
    localStorage.setItem(this.storageKey, JSON.stringify(cart));
  }

  clearLocalCart(): void {
    localStorage.removeItem(this.storageKey);
  }

  // ====== Backend API Methods ======

  addCartItemToBackend(userId: number, bookId: number, quantity: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/add?userId=${userId}`, { bookId, quantity });
  }

  updateCartItemBackend(cartItemId: number, quantity: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/update`, { cartItemId, quantity });
  }

  removeCartItemBackend(cartItemId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete/${cartItemId}`);
  }

  clearCartBackend(userId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/clear?userId=${userId}`);
  }

  // ====== Merge Local Cart to Backend ======
  syncLocalCartToBackend(userId: number): Observable<any> {
    const localCart = this.getLocalCart();
    if (localCart.length === 0) {
      return of(null);
    }

    const requests = localCart.map(item => 
      this.addCartItemToBackend(userId, item.bookId, item.quantity)
    );

    // Gửi lần lượt từng request (có thể tối ưu sau)
    return of(Promise.all(requests));
  }
}
