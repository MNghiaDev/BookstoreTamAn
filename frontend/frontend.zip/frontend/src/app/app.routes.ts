import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { BookComponent } from './pages/book/book.component';
import { BookDetailComponent } from './pages/book-detail/book-detail.component';
import { CartComponent } from './pages/cart/cart.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { CheckoutComponent } from './pages/checkout/checkout.component';
import { ThankYouComponent } from './pages/thank-you/thank-you.component';
import { LayoutComponent } from './pages/admin/layout/layout.component';
import { PaymentCallbackComponent } from './pages/payment-callback/payment-callback.component';
import { AuthorListComponent } from './pages/author-list/author-list.component';
import { AuthorDetailComponent } from './pages/author-detail/author-detail.component';
import { CategoryComponent } from './pages/category/category.component';
import { CategoryDetailComponent } from './pages/category-detail/category-detail.component';
import { NewsListComponent } from './pages/news-list/news-list.component';
import { NewsDetailComponent } from './pages/news-detail/news-detail.component';
import { CategoryListComponent } from './pages/category-list/category-list.component';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'book', component: BookComponent },
  { path: 'book-detail/:id', component: BookDetailComponent },
  { path: 'cart', component: CartComponent },
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'checkout', component: CheckoutComponent},
  { path: 'thank-you', component: ThankYouComponent},
  { path: 'admin', loadChildren: () => import('./pages/admin/admin.module').then(m => m.AdminModule) },
  { path: 'payments/payment-callback', component: PaymentCallbackComponent },
  { path: 'authors', component: AuthorListComponent},
  { path: 'author-detail/:id', component: AuthorDetailComponent},
  { path: 'categories', component: CategoryListComponent},
  { path: 'category-detail', component: CategoryDetailComponent},
  { path: 'news', component: NewsListComponent},
  { path: 'news-detail', component: NewsDetailComponent},
];
